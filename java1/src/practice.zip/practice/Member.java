package practice;

public class Member {
	
	public String id;
	public String passWord;
	public String nickName;
	
	public Member() {
		
	}
	
	public Member(String id, String passWord, String nickName) {
		this.id = id;
		this.passWord = passWord;
		this.nickName = nickName;
	}
}
