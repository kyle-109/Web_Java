package practice;

public class forTest {
	public static void main(String[] args) {
		String a = "안녕하세요\n반갑습니다\n다시만나요\n";
		String[] b =a.split("\n");
		System.out.println(b.length);
		System.out.println(b[0]);
		System.out.println(b[1]);
		System.out.println(b[2]);
		
	}
	
	
	
}
